from odoo import models
from odoo import fields


class SchoolStudent(models.Model);
  _name="school.student"
  _description="School Student Model"
 name =fields.Char(string="String Name", required=True)
  student_id =fields.Integer(string="Student ID" , required=True)
  gender =fields.Selection([('male', 'Male Student'), ('female', 'Female Student')], string="Gender")
